# Symbiotic-nodule-occupancy > Nodule_micro_v1
https://universe.roboflow.com/evgeniis-workspace-tq6ny/symbiotic-nodule-occupancy

Provided by a Roboflow user
License: CC BY 4.0

