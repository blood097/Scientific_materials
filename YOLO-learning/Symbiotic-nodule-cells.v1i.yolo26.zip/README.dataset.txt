# Symbiotic-nodule-cells > 2026-07-03 2:14pm
https://universe.roboflow.com/evgeniis-workspace-tq6ny/symbiotic-nodule-cells-uy8yi

Provided by a Roboflow user
License: CC BY 4.0

